import useAppData from "../../hooks/useAppData"
import './styles.module.scss'

const AboutPage = () => {
  return <div className="container">
    This is AboutPage
  </div>
}
export default AboutPage