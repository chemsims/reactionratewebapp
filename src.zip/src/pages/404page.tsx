import styles from './404page.module.scss'

const PageError = () => {
  return <div className={styles.container}>
    No Page
  </div>
}
export default PageError