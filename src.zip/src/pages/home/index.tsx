import useAppData from "../../hooks/useAppData"
import './styles.module.scss'

const HomePage = () => {
  return <div className="container">
    This is HomePage
  </div>
}
export default HomePage