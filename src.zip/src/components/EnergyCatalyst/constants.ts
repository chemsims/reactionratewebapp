export const CatalystDropItemColors = [
  // 'rgb(255, 0, 0)',
  // 'rgb(255, 238, 85)',
  // 'rgb(0, 208, 240)',
  'rgb(239, 81, 157)',
  'rgb(255, 238, 85)',
  'rgb(136, 233, 255)',
]