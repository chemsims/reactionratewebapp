
export const CorrectIcon = () => {
  return <div>
    <i className="fa fa-check"></i>
  </div>
}